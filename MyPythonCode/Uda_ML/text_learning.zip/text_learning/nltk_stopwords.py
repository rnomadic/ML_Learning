
# import nltk
# ltk.download('stopwords')
# Above 2 lines needed only if you ran it for first time

from nltk.corpus import stopwords
sw = stopwords.words("english")

print(sw[0])

# Lesson 11, quiz 9, stopwords from nltk
print(len(sw))

# Lesson 11, quiz 11, stemmer from nltk
from nltk.stem.snowball import SnowballStemmer

stemmer = SnowballStemmer("english")
print(stemmer.stem("responsiveness"))

print(stemmer.stem("unresponsive"))

print(stemmer.stem("responsivity"))
