#!/usr/bin/python

""" 
    Starter code for exploring the Enron data set (emails + finances);
    loads up the data set (pickled dict of dicts).

    The data set has the form:
    enron_data["LASTNAME FIRSTNAME MIDDLEINITIAL"] = { features_dict }

    {features_dict} is a dictionary of features associated with that person.
    You should explore features_dict as part of the mini-project,
    but here's an example to get you started:

    enron_data["SKILLING JEFFREY K"]["bonus"] = 5600000

    The email + finance (E+F) data dictionary is stored as a pickle file,
    which is a handy way to store and load python objects directly.
    
"""

import pickle
fileobj = open("../final_project/final_project_dataset.pkl", "r")
enron_data = pickle.load(fileobj)

"Quiz 13: How many people are there in data set"
print "no of people(data points): ", len(enron_data)  # This will print how many data points are there in the data set


"Quiz 14: How many feature are there in data set"
first_keys = enron_data.keys()[0]
print "first key of enron data: ", first_keys
no_of_features = len(enron_data[first_keys])
print "no of features: ", no_of_features  # This will print how many col are there in each row


" Quiz 15 "
" The poi feature records whether the person is a person of interest, according to our definition. "
" How many POIs are there in the E+F data set?"

" In other words, count the number of entries in the dictionary where"
" data[person_name][poi]==1"

print(enron_data["SKILLING JEFFREY K"]["poi"])  # This is just 1 example whether this person poi is true or false

cnt = 0
for users in enron_data:
    if enron_data[users]['poi']:
        cnt = cnt + 1

print "Poi count: ", cnt

# count poi using list comprehension

n = [x for x in enron_data.values() if x['poi']]

print "Poi count: ", (len(n))

'''
Below code is another way of accessing dict items

count = 0
for key, value in enron_data.iteritems():
    print(key)
    print(value["exercised_stock_options"])

'''

'''
No of email address (not used for the time being)
import sys
sys.path.append("../final_project/")
from poi_email_addresses import poiEmails

list = poiEmails()

print(len(list))
'''

""" 
Quiz 16 How many POi Exist
We compiled a list of all POI names (in ../final_project/poi_names.txt) and associated email addresses
(in ../final_project/poi_email_addresses.py).

How many POI were there total? (Use the names file, not the email addresses, 
since many folks have more than one address and a few did not work for Enron, so we don't have their emails.)

"""

import pandas as pd

data = pd.read_csv('../final_project/poi_names.txt')
print "shape of the poi_names.txt: ", data.shape

# sum = sum(enron_data["James Prentice"]["feature_name"])

# Quiz 18, 19
print(enron_data["METTS MARK"])  # This will print all the values of

def is_key_present(grade, key):
    if key in grade:
        return True
    else:
        return False

# Quiz 18, "James Prentice" not present in this data set, so I use another name
print(is_key_present(enron_data, "James Prentice"))


print(enron_data["METTS MARK"]["total_stock_value"])

#Quiz 19, Wesley Colwell not presnt so I use another name
print(is_key_present(enron_data, "Wesley Colwell"))
print(enron_data["METTS MARK"]["from_this_person_to_poi"])

#Quiz 20 Jeffrey K Skilling
print(is_key_present(enron_data, "Jeffrey K Skilling"))

print(enron_data["METTS MARK"]["exercised_stock_options"])

