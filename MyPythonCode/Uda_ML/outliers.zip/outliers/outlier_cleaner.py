#!/usr/bin/python


def outlierCleaner(predictions, ages, net_worths):
    """
        Clean away the 10% of points that have the largest
        residual errors (difference between the prediction
        and the actual net worth).

        Return a list of tuples named cleaned_data where 
        each tuple is of the form (age, net_worth, error).
    """

    """
    Our aim is to find outliers and then get rid of them. So, firstly we calculated errors and then,
    
    on line 2;
    created a new list of tuples that consists of 'ages', 'net_worths' and 'errors' by using zip() function.
    (You can check what zip() function does from here: https://docs.python.org/2/library/functions.html#zip 6 )
    Outliers are extreme or compared higher error values. In our assignment, we don't wan't highest error values 
    which are %10 of total elements in our case. 
    
    So on line 3;
    we sorted our 'cleaned_data' by error values, from higher to lower('reverse=True' does that) by using sorted() 
    and lambda functions. (key=lambda x: x[2] => since cleaned_data is tuple 
    and we want to sort cleaned_data based on the errors, we use x: x[2]. Since our x[0] is age, x[1] is net worth) 
    For further information about sorted() and lambda functions in python, you can check:
    https://docs.python.org/2/library/functions.html#sorted
    https://docs.python.org/2/howto/functional.html?highlight=lambda#small-functions-and-the-lambda-expression
    https://docs.python.org/2/howto/sorting.html
    
    On line 4 & 5;
    we got 81 elements without 9 elements that have higher error values in our data.
    """
    cleaned_data = []

    ### your code goes here

    errors = (net_worths - predictions) ** 2
    cleaned_data = zip(ages, net_worths, errors)  # Create a tuple
    cleaned_data = sorted(cleaned_data, key=lambda x: x[2], reverse=True)  # sort tuple on High to low, based on errors
    limit = int(len(net_worths) * 0.1)  # 10% reduction, 90*0.1 = 81
    return cleaned_data[limit:]  # take the 81 element, remove top 9 errors
    
    #return cleaned_data

